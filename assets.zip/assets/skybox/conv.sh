#!/bin/bash

# Loop through all .ppm files in the current directory
for file in *.ppm; do
    # Check if the file exists (to avoid errors if no .ppm files are present)
    [ -e "$file" ] || continue

    # Convert and resize to 1024x1024 while keeping it in PPM format
    convert "$file" -resize 1024x1024 -compress none "${file%.*}_resized.ppm"

    echo "Resized: $file → ${file%.*}_resized.ppm"
done

echo "All PPM files resized!"
